# Assignment 3 — Multi-Client Chat Application

A complete academic/demo implementation using **Node.js, Express, Socket.IO, Multer and Gemini API**.

## Features

- Multi-client real-time chat using Socket.IO.
- Multiple chatrooms; clients can create/join rooms.
- One-to-one private messages by clicking an online client.
- Image/video upload and distribution to all clients in the current room.
- Server-side Gemini moderation for trolling detection.
- Gemini generates a calm/soothing response when trolling is detected.
- OTP / verification-code detection with an explicit confirmation dialog before group delivery.
- Automatic online-user list.
- Typing indicator.
- Graceful fallback to a small local trolling heuristic if the Gemini key is unavailable.
- No real API key is included in this ZIP.

## Requirements

- Node.js 18 or newer.
- Internet connection for Gemini API calls.
- A Gemini API key for AI moderation.

Google's current documentation recommends the Google GenAI JavaScript SDK and environment-variable API keys. See:
https://ai.google.dev/gemini-api/docs/get-started

## 1. Install dependencies

Open the project folder in VS Code, then in the terminal:

```powershell
npm install
```

## 2. Configure Gemini

Copy `.env.example` to `.env`.

Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Open `.env` and replace:

```text
GEMINI_API_KEY=PASTE_YOUR_GEMINI_API_KEY_HERE
```

with your real key.

**Do not put the key inside `server.js`, `app.js`, or any file committed/submitted publicly.**

## 3. Start the server

```powershell
npm start
```

You should see:

```text
Server running at http://localhost:3000
Gemini moderation: ENABLED
```

Open:

```text
http://localhost:3000
```

## 4. Demonstrate multiple clients

Open two or three browser windows/tabs.

Example:

- Client 1: Alice, room General
- Client 2: Bob, room General
- Client 3: Charlie, room General

Send a normal message from Alice. It should appear on the other clients.

### Test rooms

From Bob, enter `Sports` in the room box and press `+`.

Bob moves to `#Sports`. Alice remains in `#General`.

### Test one-to-one messaging

Click another online client in the left panel. Enter a private message in the browser prompt.

Only the sender and selected receiver see the private message.

### Test image/video

Click the paperclip button and choose an image or video. The browser uploads it to the server, and Socket.IO distributes the media URL to clients in the same room.

### Test trolling detection

With Gemini configured, send a clearly hostile/inflammatory message. The server sends the text to Gemini for moderation. If Gemini classifies it as trolling, the original text is not broadcast. Instead the room receives a calm moderation response.

### Test OTP confirmation

Send something like:

```text
My OTP is 123456
```

The server detects the possible OTP and sends a confirmation dialog to the sender.

- Cancel → message is not sent.
- Yes, send to group → the server continues processing and can broadcast it.

## Architecture

```text
Browser Client
     |
     | HTTP / WebSocket
     v
Express + Socket.IO Server
     |
     +---- Room state / online users
     |
     +---- Multer -> uploads/
     |
     +---- Gemini API -> trolling analysis
     |
     +---- OTP detector -> confirmation -> group broadcast
     |
     +---- Direct message routing
```

### Protocol/layer observations

1. **Application layer:** browser UI, HTTP upload endpoint, Socket.IO events.
2. **Transport layer:** TCP is used underneath HTTP/WebSocket connections.
3. **WebSocket/Socket.IO layer:** full-duplex real-time communication and event routing.
4. **File-transfer path:** HTTP multipart upload -> server filesystem -> media URL -> Socket.IO event.
5. **AI moderation path:** client -> Socket.IO -> server -> Gemini HTTPS API -> server decision -> room event.
6. **State layer:** in-memory Maps store connected users, rooms and pending confirmations.

## Design patterns encountered

- **Client–Server architecture:** one server coordinates many browser clients.
- **Event-driven architecture:** Socket.IO event handlers react to messages, joins, uploads, typing and disconnects.
- **Observer / Publish-Subscribe:** room broadcasts are similar to publish-subscribe; a client publishes an event and the server distributes it to subscribers.
- **Facade:** server functions such as `detectTrollingWithGemini()` hide API details from the Socket.IO handlers.
- **Repository-like in-memory state:** `users`, `rooms`, and `pendingPrivate` centralize transient application state.
- **Middleware pipeline:** Express middleware handles JSON, static files and Multer uploads.

## Important academic limitation

This is an educational implementation. User/room state is held in memory, so restarting the server clears connected-user state. For production, use authentication, persistent storage, stronger authorization, virus scanning, object storage, rate limiting, HTTPS, CSRF protection where applicable, and a production-grade moderation policy.

## Troubleshooting

### `npm` is not recognized

Install Node.js 18+ and restart VS Code.

### Port 3000 is already in use

In PowerShell:

```powershell
netstat -ano | findstr :3000
```

Then stop the process or change `PORT=3001` in `.env`.

### Gemini says disabled

Check that `.env` exists and contains a valid:

```text
GEMINI_API_KEY=...
```

Then restart `npm start`.

### Browser is blank

Check the terminal for errors. Then open:

```text
http://localhost:3000
```

Do not open `index.html` directly with `file://`.

### Upload fails

Only image/video files up to 20 MB are accepted.

## Submission checklist

- `server.js`
- `public/index.html`
- `public/style.css`
- `public/app.js`
- `package.json`
- `.env.example`
- `README.md`
- `REPORT.md`
- `uploads/.gitkeep`

Do not submit `.env` containing your secret key.
