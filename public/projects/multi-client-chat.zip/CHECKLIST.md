# Demo Checklist

Before demonstration:

- [ ] Node.js 18+ installed
- [ ] `npm install` completed
- [ ] `.env` created
- [ ] `GEMINI_API_KEY` configured
- [ ] `npm start` running
- [ ] Browser opened at `http://localhost:3000`
- [ ] Two or three clients connected
- [ ] Normal room message tested
- [ ] Room switching tested
- [ ] One-to-one message tested
- [ ] Image/video tested
- [ ] Trolling detection tested
- [ ] OTP confirmation tested

Useful terminal check:

```powershell
Invoke-RestMethod http://localhost:3000/api/health
```

Expected output contains:

```text
ok : True
geminiConfigured : True
```

If `geminiConfigured` is false, check `.env` and restart the server.
