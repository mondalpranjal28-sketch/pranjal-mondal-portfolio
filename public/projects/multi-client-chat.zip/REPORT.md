# Detailed Experiment Report
## Assignment 3: Implement a Multi-Client Chat Application

### 1. Objective

The objective is to implement a multi-client chat application in Node.js in which several clients connect to a single server and communicate through chatrooms. The application also supports one-to-one messages and image/video sharing.

Two optional server capabilities from the assignment are implemented:

1. Gemini-based trolling detection with a calm response.
2. Detection of OTP/verification-code-like information followed by an explicit confirmation before sending it to a group.

### 2. Technology stack

| Component | Technology |
|---|---|
| Runtime | Node.js 18+ |
| Web framework | Express |
| Real-time communication | Socket.IO |
| File upload | Multer |
| AI moderation | Google Gemini API via `@google/genai` |
| Front end | HTML, CSS, JavaScript |
| State | In-memory JavaScript Maps |

### 3. High-level architecture

The server is the central coordinator.

```text
+----------------+       Socket.IO        +------------------------+
| Client A       | <--------------------> |                        |
+----------------+                         |                        |
                                           |     Node.js Server     |
+----------------+       Socket.IO        |                        |
| Client B       | <--------------------> | Express + Socket.IO   |
+----------------+                         |                        |
                                           |  +------------------+  |
+----------------+       Socket.IO        |  | Room/User State  |  |
| Client C       | <--------------------> |  +------------------+  |
+----------------+                         |           |              |
                                           |      Gemini API         |
                                           +------------------------+
```

### 4. Client-server protocol

The browser first loads the application over HTTP.

The Socket.IO client then establishes a persistent real-time connection. Socket.IO uses WebSocket when available and provides fallback/connection-management behavior.

Important application events:

| Event | Direction | Purpose |
|---|---|---|
| `register` | Client -> Server | Register username and initial room |
| `registered` | Server -> Client | Confirm registration |
| `chat-message` | Client -> Server | Send room text |
| `chat-message` | Server -> Clients | Broadcast approved text |
| `join-room` | Client -> Server | Change room |
| `room-changed` | Server -> Client | Confirm room change |
| `direct-message` | Both directions | One-to-one communication |
| `send-media` | Client -> Server | Announce uploaded media |
| `chat-media` | Server -> Room | Distribute media |
| `typing` | Both directions | Typing indicator |
| `private-info-warning` | Server -> Sender | OTP confirmation |
| `confirm-private-send` | Client -> Server | Approve/cancel OTP message |
| `moderation-message` | Server -> Room | Calm response after trolling detection |

### 5. Text message algorithm

```text
Client types message
       |
       v
Socket.IO -> server
       |
       +---- Is it empty? ---- yes --> discard
       |
       +---- Is it OTP-like? ---- yes --> confirmation dialog
       |                                  |
       |                                  +-- cancel --> stop
       |                                  |
       |                                  +-- approve --> moderation
       |
       v
Gemini moderation
       |
       +---- trolling --> soothing room response
       |
       +---- normal ----> broadcast to room
```

### 6. Gemini trolling detection

The server uses the Google GenAI JavaScript SDK.

The key is read from the environment:

```text
GEMINI_API_KEY
```

The moderation prompt asks Gemini to return JSON:

```json
{
  "isTrolling": false,
  "confidence": 0.0,
  "reason": "short reason",
  "soothingMessage": "short calm message"
}
```

The server parses the result and decides whether the original text should be distributed.

If Gemini is unavailable, a small local heuristic is used so that the project can still be demonstrated. This fallback is intentionally not presented as an equivalent AI detector.

### 7. Why moderation happens on the server

The API key must not be exposed to browser JavaScript.

Correct:

```text
Browser -> Node.js server -> Gemini API
```

Incorrect:

```text
Browser -> Gemini API using secret key
```

The server therefore acts as a trusted API boundary.

### 8. OTP confirmation mechanism

The server checks for patterns such as:

- `OTP`
- `one-time password`
- `verification code`
- common 4–8 digit code patterns

When detected, the server does not immediately broadcast the message.

It stores a temporary pending record:

```text
confirmationId
sender socket ID
room
message
timestamp
```

The sender receives `private-info-warning`.

The browser displays a confirmation modal. Only an explicit approval causes the server to continue.

### 9. Image/video protocol

The media path is:

```text
Browser
  |
  | multipart/form-data POST /upload
  v
Multer
  |
  v
uploads/<generated filename>
  |
  | JSON response containing URL
  v
Browser
  |
  | Socket.IO send-media
  v
Server
  |
  | chat-media
  v
All clients in current room
```

The server restricts media to common image/video MIME types and a 20 MB limit.

### 10. Multi-client behavior

Each connected client is represented by:

```text
socket.id -> {
  username,
  room
}
```

Each room is represented by:

```text
room name -> Set(socket.id)
```

When a message arrives, the server uses the room membership to distribute it only to clients in that room.

This allows clients to join and leave rooms dynamically.

### 11. One-to-one communication

For private communication, the client selects another connected user's socket ID.

The server sends the message:

- back to the sender, so the sender sees the outgoing message;
- directly to the target socket.

It is not sent to the room broadcast channel.

### 12. Framework used

The project follows the **Express** web application framework for:

- HTTP server setup,
- static file serving,
- JSON middleware,
- file-upload endpoint.

**Socket.IO** is used as the real-time communication framework/library.

### 13. Design patterns encountered

#### Client–Server
All clients communicate through one central server.

#### Event-driven architecture
Socket.IO handlers respond to events rather than repeatedly polling the server.

#### Observer / Publish-Subscribe
A room behaves similarly to a topic. A message published to the room is received by its subscribers.

#### Facade
`detectTrollingWithGemini()` hides Gemini SDK/API details from the rest of the server.

#### Middleware pipeline
Express and Multer process HTTP requests through middleware.

### 14. Protocol layer observations

#### Application layer
HTTP, Express routes, Socket.IO events and the Gemini API request operate at the application level.

#### Transport layer
TCP provides reliable delivery for HTTP/WebSocket traffic.

#### Real-time session behavior
Socket.IO maintains a persistent logical connection and exposes event-based communication.

#### File transfer
Files use multipart/form-data over HTTP, after which clients receive a normal server URL.

### 15. Experiments to perform

#### Experiment A — Two clients
1. Open two browser windows.
2. Register Alice and Bob in `General`.
3. Send a message.
4. Observe that both clients receive it.

Expected result: room broadcast.

#### Experiment B — Room isolation
1. Alice remains in `General`.
2. Bob joins `Sports`.
3. Alice sends a message in `General`.

Expected result: Bob does not receive the General-room message.

#### Experiment C — One-to-one
1. Connect Alice and Bob.
2. Alice clicks Bob.
3. Enter a private message.

Expected result: only Alice and Bob see it.

#### Experiment D — Image/video
1. Select an image or supported video.
2. Upload.
3. Observe it in the current room.

Expected result: media appears to all clients in that room.

#### Experiment E — Gemini moderation
1. Configure `GEMINI_API_KEY`.
2. Restart server.
3. Send an intentionally inflammatory/trolling message.
4. Observe Gemini moderation response.

Expected result: original trolling message is blocked and a calm message is shown.

#### Experiment F — OTP confirmation
1. Send a message containing a test OTP such as `OTP is 123456`.
2. Observe the confirmation modal.
3. Cancel.

Expected result: message is not sent.

Repeat and approve.

Expected result: server continues processing and the message can be distributed.

### 16. Security and reliability considerations

This academic project intentionally keeps the implementation understandable.

A production deployment should additionally use:

- HTTPS/WSS,
- authentication and authorization,
- database-backed state,
- Redis adapter for multiple server instances,
- rate limiting,
- stronger validation,
- antivirus/media scanning,
- safe object storage,
- strict content-security policy,
- audit logging,
- API quotas and retry policies,
- moderation policy and human review for uncertain cases.

### 17. Limitations

- State is in memory.
- No login/password system.
- No database.
- Media is stored locally.
- Gemini availability depends on the API key and network.
- The fallback trolling detector is intentionally basic.
- OTP detection is pattern-based and can have false positives.

### 18. Conclusion

The project demonstrates a complete multi-client real-time chat architecture using Node.js. It shows room-based broadcasting, private communication, media transfer, event-driven design, and server-side integration with a generative AI moderation service.

The application also demonstrates an important architectural principle: secret API credentials belong on the server, while browser clients communicate with the server through controlled application events.
